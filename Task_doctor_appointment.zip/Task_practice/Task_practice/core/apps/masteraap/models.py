from django.db import models
from apps.masteraap.basecontent import *

# Create your models here.
 
class Category(BaseContent):
    categoryName = models.CharField(max_length=255,unique=True)
    
    DisplayList = ['id','categoryName']
    searchable_fields = ['id','categoryName']
    class Meta:
        db_table ='masterapp_MainCategory'

    def __str__(self):
        return self.categoryName

class SubCategory(BaseContent):
    subCategoryName = models.CharField(max_length=255,unique=True) 
    category = models.ForeignKey(to=Category, on_delete=models.CASCADE)
    
   
    DisplayList = ['id','category','category_id']
    searchable_fields = ['id','sub_category_name']
    class Meta:
        db_table ='masterapp_SubCategory'

    def __str__(self):
        return self.subCategoryName

class DoctorProfile(BaseContent):
    doctorName = models.CharField(max_length=255,unique=True)
    image=models.FileField(upload_to='images/')
    subcategory=models.ForeignKey(to=SubCategory, on_delete=models.CASCADE)   
    location=models.CharField(max_length=255)
    patients=models.IntegerField()
    years_experience=models.IntegerField()
    review=models.IntegerField()
    rating=models.IntegerField()
    about = models.TextField(default="No information available")

    DisplayList = ['id','doctorName','image','subcategory_id']
    searchable_fields = ['id','doctorName']
    class Meta:
        db_table ='masterapp_DoctorProfile'


class Country(BaseContent):
    country = models.CharField(max_length=100, unique=True)
    # countryCode  = models.CharField(max_length=10)
    # flag = models.FileField(upload_to='images/flag/',null=True)
    # slug = models.SlugField(unique=True)

    DisplayList = ['id','country','isActive']
    searchable_fields = ['id','country']
    class Meta:                 
        db_table ='masterapp_country'

    def __str__(self):
        return self.country
    

class State(BaseContent):
    country  = models.ForeignKey(to=Country, on_delete=models.CASCADE)
    state = models.CharField(max_length=100, unique=True)

    DisplayList = ['id','state','isActive']
    searchable_fields = ['id','state']
    filter_fields = ['id','state']
    class Meta:
        db_table ='masterapp_state'

    def __str__(self):
        return self.state
    



from django.urls import path
from apps.masteraap.views.admin_view import *
from apps.masteraap.views.admin_api_view import *

urlpatterns = [
  
    path('',login ,name='login'),
    path('index/',index ,name='index'),

    path('category/', CategoryView.as_view(), name='category'),
    path('category/<int:id>/', CategoryView.as_view(), name='category'),
    
    path('subcategory/', SubCategoryView.as_view(), name='subcategory'),
    path('subcategory/<int:id>/', SubCategoryView.as_view(), name='subcategory'),
   
    path('doctorprofile/', DoctorProfileView.as_view(), name='doctorprofile'),
    path('doctorprofile/<int:id>/', DoctorProfileView.as_view(), name='doctorprofile'),

    path('country/', CountryView.as_view(), name='country'),
    path('country/<int:id>/', CountryView.as_view(), name='country'),

     path('state/', StateView.as_view(), name='state'),
    path('state/<int:id>/', StateView.as_view(), name='state'),




    ###################### APIS ###################################

     path('countries/', CountryListView.as_view(), name='country'),
     path('state/', StateListView.as_view(), name='state'),
     path('doctorprofiles/', DoctorProfileAPIView.as_view(), name='doctorprofile'),
     path('subcategory/', SubCategoryAPIView.as_view(), name='subcategory'),

]

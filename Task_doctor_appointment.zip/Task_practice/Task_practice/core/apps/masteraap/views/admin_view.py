from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login as auth_login
from django.contrib import messages
from django.shortcuts import get_object_or_404
from apps.masteraap.models import *
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q
from rest_framework.views import View
from django.contrib import messages




def login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        print(email, password)
        
        # Validate inputs
        if not email or not password:
            messages.error(request, 'Please provide both email and password')
            return render(request, "login.html")
        
        try:
            user = authenticate(request, email=email, password=password)
            if user is not None:
                auth_login(request, user)
                # Redirect to a specific page after successful login
                return redirect('index')  # Assuming 'profile' is the name of the URL pattern for the user's profile
            else:
                messages.error(request, 'Invalid username or password')
        except Exception as e:
            # Log the exception for debugging
            print(f"Exception during login: {e}")
            messages.error(request, 'An error occurred while trying to login')

    # Render the login page for GET requests and unsuccessful login attempts
    return render(request, "login.html")

    


    
def index(request):
    return render(request,"index.html")
    


class CountryView(View):
    def get(self, request, id=None):
        if id:
            country = get_object_or_404(Country, pk=id)
            country.delete()
            messages.success(request, 'A Country is deleted successfully.')
            return redirect('/country')
           
        else:
            if "q" in request.GET:
                searchobj = request.GET.get("q")
                multiple_q = Q(Q(country__icontains=searchobj))
                data = Country.objects.filter(multiple_q)
            else:
                data = Country.objects.all()
 
            page_number = request.GET.get('page', 1)
            paginator = Paginator(data, 5)
            try:
                    data = paginator.page(page_number)
            except PageNotAnInteger:
                    data = paginator.page(1)
            except EmptyPage:
                    data = []
 
            if "q" in request.GET:
                context = {'data': data, 'q': request.GET.get("q")}
            else:
                context = {'data': data}
 
            return render(request, 'country.html',context  )
 
    def post(self, request, id=None):
        if id:
            # country = get_object_or_404(Country, pk=id)
            country = get_object_or_404(Country, pk=id)
            if 'status_update' in request.POST:
                if country.isActive:
                    country.isActive=False
                else:
                    country.isActive=True
                country.save()
                messages.success(request, 'A Country status updated successfully.')
                return redirect('/country')
           
            country_name = request.POST.get('country_name')
          
 
                    # Retrieve the existing country object from the database
            country = get_object_or_404(Country, pk=id)
 
               
            if (country.country != country_name):
 
                       
                        country.country = country_name
 
                       
                        country.save()
                        messages.success(request, 'Country information updated successfully.')            
            return redirect('/country')
 
        else:
            country_name=request.POST['country_name']
            if Country.objects.filter(country=country_name).exists():
                    messages.error(request, 'A Country with same name already exists.')
                    return redirect('/country')
            else:
                try:
                    country_master=Country(country=country_name)
                    country_master.save()
                    messages.success(request, 'A Country Created Successfully..')
                except Exception as e:
                    messages.error(request, f'An error occurred slug be Unique')
            return redirect('/country')


class StateView(View):
    def get(self, request, id=None):
        if id:
            state = get_object_or_404(State, pk=id)
            state.delete()
            messages.success(request, 'A State is deleted successfully.')
            return redirect('/state')
        else:
            if "q" in request.GET:
                searchobj = request.GET.get("q")
                multiple_q = Q(Q(state__icontains=searchobj))
                data = State.objects.filter(multiple_q)
            else:
                
                if "q" in request.GET:
                    searchobj = request.GET.get("q")
                    multiple_q = Q(Q(state__icontains=searchobj))
                    data = State.objects.filter(multiple_q)
                else:
                    countryobj = Country.objects.all()
                    data = State.objects.all()
            # Pagination
            page_number = request.GET.get('page', 1)
            paginator = Paginator(data, 5)
            try:
                    data = paginator.page(page_number)
            except PageNotAnInteger:
                    data = paginator.page(1)
            except EmptyPage:
                    data = []

            if "q" in request.GET:
                context = {'data': data, 'q': request.GET.get("q"),'countryobj':countryobj}
            else:
                context = {'data': data,'countryobj':countryobj}
            
            return render(request, 'state.html', context)

    def post(self, request, id=None):
        
        if id:
            state = get_object_or_404(State, pk=id)
            if 'status_update' in request.POST:
                # Toggle the isActive field
                state.isActive = not state.isActive
                state.save()
                messages.success(request, 'State status updated successfully.')
                return redirect('/state')

            state_name = request.POST.get('state_name')
            # country_id = request.POST.get('country_id')
            # country_id = request.POST.get('country_id')
            state = get_object_or_404(State, pk=id)

            if State.objects.filter(state=state_name).exists():
                messages.error(request, 'A State with the same name in the selected country already exists.')
                return redirect('/state')
            else:
                try:
                    state.state = state_name
                    
                    state.save()
                    messages.success(request, 'State information updated successfully.')
                except Exception as e:
                    messages.error(request, f'An error occurred: {e}')
            return redirect('/state')
        else:
            state_name = request.POST.get('state_name')
            country_id = request.POST.get('country_id')
            country = get_object_or_404(Country, pk=country_id)

            if State.objects.filter(state=state_name, country=country).exists():
                messages.error(request, 'A State with the same name in the selected country already exists.')
                return redirect('/state')
            else:
                try:
                    state_obj = State(state=state_name, country=country)
                    state_obj.save()
                    messages.success(request, 'State created successfully.')
                except Exception as e:
                    messages.error(request, f'An error occurred: {e}')
            return redirect('/state')

    def delete(self, request, state_id):
        state = get_object_or_404(State, pk=state_id)
        state.delete()
        return redirect('/state')







class CategoryView(View):
    def get(self, request, id=None):
        if id:
            category = get_object_or_404(Category, pk=id)
            category.delete()
            messages.success(request, 'A Category is deleted successfully.')
            return redirect('/category')
           
        else:
            if "q" in request.GET:
                searchobj = request.GET.get("q")
                data = Category.objects.filter(name__icontains=searchobj)
            else:
                data = Category.objects.all()
 
            page_number = request.GET.get('page', 1)
            paginator = Paginator(data, 5)
            try:
                data = paginator.page(page_number)
            except PageNotAnInteger:
                data = paginator.page(1)
            except EmptyPage:
                data = []
 
            if "q" in request.GET:
                context = {'data': data, 'q': request.GET.get("q")}
            else:
                context = {'data': data}
 
            return render(request, 'category.html', context)
 
    
    def post(self, request, id=None):
        if id:
            category = get_object_or_404(Category, pk=id)
            if 'status_update' in request.POST:
                category.is_active = not category.is_active
                category.save()
                messages.success(request, 'Category status updated successfully.')
        else:
            category_name = request.POST.get('category_name')

            if Category.objects.filter(categoryName=category_name).exists():
                messages.error(request, 'A Category with the same name already exists.')
            else:
                try:
                    category = Category.objects.create(categoryName=category_name)
                    messages.success(request, 'A Category Created Successfully.')
                except Exception as e:
                    messages.error(request, 'An error occurred while creating the category.')

        return redirect('/category')




# def delete_category(request, id):
#     category = get_object_or_404(Category, pk=id)
#     try:
#         category.delete()
#         messages.success(request, 'Category deleted successfully.')
#     except Exception as e:
#         messages.error(request, 'An error occurred while deleting the category.')
    
#     return redirect('/category')



class SubCategoryView(View):

    def get(self, request, id=None):

        if id:
            subcategory = get_object_or_404(SubCategory, pk=id)
            subcategory.delete()
            messages.success(request, 'A Sub-Category is deleted successfully.')
            return redirect('/subcategory')
        else:
            if "q" in request.GET:
                searchobj = request.GET.get("q")
                data = SubCategory.objects.filter(subCategoryName__icontains=searchobj)
            else:
                data = SubCategory.objects.all()

            # Pagination
            page_number = request.GET.get("page", 1)
            paginatorobj = Paginator(data, 10)
            try:
                data = paginatorobj.page(page_number)
            except PageNotAnInteger:
                data = paginatorobj.page(1)
            except EmptyPage:
                data = paginatorobj.page(paginatorobj.num_pages)

            maincatobj = Category.objects.all()
            return render(request, 'subcategory.html', {'data': data, 'maincatobj':maincatobj})

    def post(self, request, id=None):
        if id:
            subctegory = get_object_or_404(SubCategory, pk=id)
            if subctegory.isActive:
                subctegory.isActive=False
            else:
                subctegory.isActive=True
            subctegory.save()
            messages.success(request, 'A Sub-Category status updated successfully.')
            return redirect('/subcategory')
        else:
            sub_category_name = request.POST.get('sub_category_name')
            category_id = request.POST.get('category_id')
            

            if SubCategory.objects.filter(subCategoryName=sub_category_name).exists():
                messages.error(request, 'A SubCategory with the same name already exists.')
                return redirect('/subcategory')
            else:
                try:
                    sub_category_instance = SubCategory(subCategoryName=sub_category_name, category_id=category_id,)
                    sub_category_instance.save()
                    messages.success(request, 'A SubCategory Created Successfully..')
                except Exception as e:
                    messages.error(request, f'An error occurred: {str(e)}')

            return redirect('/subcategory')
        
class DoctorProfileView(View):
    def get(self, request, id=None):
        if id:
            doctor_profile = get_object_or_404(DoctorProfile, pk=id)
            doctor_profile.delete()
            messages.success(request, 'Doctor profile is deleted successfully.')
            return redirect('/doctorprofile')
        else:
            if "q" in request.GET:
                search_query = request.GET.get("q")
                data = DoctorProfile.objects.filter(name__icontains=search_query)
            else:
                data = DoctorProfile.objects.all()

            # Pagination
            page_number = request.GET.get("page", 1)
            paginator = Paginator(data, 10)
            try:
                data = paginator.page(page_number)
            except PageNotAnInteger:
                data = paginator.page(1)
            except EmptyPage:
                data = paginator.page(paginator.num_pages)

            return render(request, 'doctorprofile.html', {'data': data})

    def post(self, request, id=None):
        if id:
            doctor_profile = get_object_or_404(DoctorProfile, pk=id)
            doctor_profile.is_active = not doctor_profile.is_active
            doctor_profile.save()
            messages.success(request, 'Doctor profile status updated successfully.')
            return redirect('/doctorprofile')
        else:
            name = request.POST.get('name')
            # Add other fields as needed

            if DoctorProfile.objects.filter(name=name).exists():
                messages.error(request, 'A doctor profile with the same name already exists.')
                return redirect('/doctorprofile')
            else:
                try:
                    doctor_profile_instance = DoctorProfile(name=name)
                    # Add other fields to the instance creation
                    doctor_profile_instance.save()
                    messages.success(request, 'Doctor profile created successfully.')
                except Exception as e:
                    messages.error(request, f'An error occurred: {str(e)}')

            return redirect('/doctorprofile')




# def add_favorite_doctor(request, doctor_id):
#     if request.user.is_authenticated:
#         FavoriteDoctor.objects.get_or_create(user=request.user, doctor_id=doctor_id)
#     return redirect('doctor_detail', doctor_id=doctor_id)

# def remove_favorite_doctor(request, doctor_id):
#     if request.user.is_authenticated:
#         FavoriteDoctor.objects.filter(user=request.user, doctor_id=doctor_id).delete()
#     return redirect('doctor_detail', doctor_id=doctor_id)

from rest_framework.response import Response
from apps.masteraap.models import *
from apps.masteraap.serializers import *
from rest_framework.views import APIView
from apps.masteraap.util import *


class CountryListView(APIView):
    def get(self, request):
        try:
            countries = Country.objects.all()
            serializer = CountrySerializer(countries, many=True)
            return Response({'data': serializer.data, 'msg': 'success'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(error(self,msg='Error'))
        


class StateListView(APIView):
    def get(self, request):
        try:
            states = State.objects.all()
            serializer = StateSerializer(states, many=True)
            return Response({'data': serializer.data, 'msg': 'success'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'msg': 'Error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class DoctorProfileAPIView(APIView):
    def get(self, request):
        try:
            doctor_profiles = DoctorProfile.objects.all()
            serializer = DoctorProfileSerializer(doctor_profiles, many=True)
            return Response({'data': serializer.data, 'msg': 'success'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'msg': 'Error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        

class SubCategoryAPIView(APIView):
    def get(self, request):
        try:
            subcategories = SubCategory.objects.all()
            serializer = SubCategorySerializer(subcategories, many=True)
            return Response({'data': serializer.data, 'msg': 'success'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'msg': 'Error'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        



from django.contrib import admin
from apps.userapp.models import *
# Register your models here.
# @admin.register(Profile)
# class ProfileAdmin(admin.ModelAdmin):
#     list_display = ['id', 'name']
#     search_fields = Profile.searchable_fields 



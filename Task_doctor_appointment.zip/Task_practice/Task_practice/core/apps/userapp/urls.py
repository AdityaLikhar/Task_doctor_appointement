from django.urls import path
from apps.userapp.views.web_view import *
from apps.userapp.views.accounts_view import *

urlpatterns = [
    #######################  Account APIS ###################################   
    path('profile_update/', ProfileUpdateView.as_view(), name='profile_update'),
    path('profile_update/<int:id>/', ProfileUpdateView.as_view(), name='profile_update'),

    path("faqs_category_qa/",FaqsCategoryQA.as_view(),name="faqs_category_qa"),
    path("faqs_category/",FaqsCategoryView.as_view(),name="faqs_category"),





    #######################  web view APIS ################################### 
    path('sign_in/',SigninView.as_view(),name="signin"),
]
from rest_framework import serializers
from . models import *

class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Profile
        fields = '__all__'


class FaqsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Faqs
        fields = '__all__'
 
class FaqsCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = FaqsCategory
        fields = '__all__'
        
from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login as auth_login
from django.contrib import messages
from rest_framework.views import APIView
from apps.userapp.models import *
from rest_framework.response import Response
from apps.userapp.serializers import *
from apps.masteraap.util import *


class ProfileUpdateView(APIView):
    def put(self, request):
        userId = request.data.get('userId')
        profile_image = request.data.get('profile_image')
        full_name = request.data.get('full_name')
        email = request.data.get('email')
        phone = request.data.get('phone')
        gender = request.data.get('gender')
        dob = request.data.get('dob')

        try:
            profile = Profile.objects.get(user_id=userId)
        except Profile.DoesNotExist:
            return Response({'error': 'Profile does not exist'}, status=status.HTTP_404_NOT_FOUND)

        # Update profile fields
        if profile_image:
            profile.profile_image = profile_image
        if full_name:
            profile.full_name = full_name
        if email:
            profile.email = email
        if phone:
            profile.phone_number = phone
        if gender:
            profile.gender = gender
        if dob:
            profile.dob = dob

        profile.save()

        serializer = ProfileSerializer(profile)

        return Response(serializer.data)

    def get(self, request):
        userId = request.GET.get('userId')
        try:
            profileobj = Profile.objects.get(user=userId)
            serializer = ProfileSerializer(profileobj)
            return Response(serializer.data, msg='success')
        except Profile.DoesNotExist:
            return Response(error(self,msg='error'))



        


class FaqsCategoryQA(APIView):
    def get(self, request):
        faqs = Faqs.objects.all()
        faqs_serializer = FaqsSerializer(faqs, many=True)
        return Response(success(self, data=faqs_serializer.data, msg='success'))
 
class FaqsCategoryView(APIView):
    def get(self, request):
        faqsCategory = Faqs.objects.all()
        faqsCategory_serializer = FaqsCategorySerializer(faqsCategory, many=True)
        return Response(success(self, data=faqsCategory_serializer.data, msg='success'))
 
 
       
from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login as auth_login
from django.contrib import messages
from rest_framework.views import View


def login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        print(email, password)
        
        # Validate inputs
        if not email or not password:
            messages.error(request, 'Please provide both email and password')
            return render(request, "login.html")
        
        try:
            user = authenticate(request, email=email, password=password)
            if user is not None:
                auth_login(request, user)
                # Redirect to a specific page after successful login
                return redirect('index')  # Assuming 'profile' is the name of the URL pattern for the user's profile
            else:
                messages.error(request, 'Invalid username or password')
        except Exception as e:
            # Log the exception for debugging
            print(f"Exception during login: {e}")
            messages.error(request, 'An error occurred while trying to login')

    # Render the login page for GET requests and unsuccessful login attempts
    return render(request, "login.html")
    
def index(request):
    return render(request,"index.html")
    


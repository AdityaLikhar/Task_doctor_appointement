from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from apps.userapp.models import *
from rest_framework_simplejwt.tokens import RefreshToken 
from apps.userapp.serializers import *
from django.core.mail import send_mail
from datetime import datetime, timedelta, timezone
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from apps.userapp  import *


# class RegistrationsView(APIView):
#     permission_classes = [AllowAny]

#     def post(self, request):
#         data = request.data
#         full_name = data.get('full_name')
#         email = data.get('email')
#         phone_number = data.get('phone_number')
#         username = data.get('username')
#         password = data.get('password')
#         confirm_password = data.get('confirm_password')
#         date_of_birth = data.get('date_of_birth')

#         if not all([full_name, email, phone_number, username, password, confirm_password, date_of_birth]):
#             return error_response("All fields are required!")

#         if password != confirm_password:
#             return error_response('Password and confirm password do not match')

#         if UserAuth.objects.filter(email=email).exists():
#             return error_response("Email is already registered. Please use a different email.")

#         if UserAuth.objects.filter(phone_number=phone_number).exists():
#             return error_response("Phone number is already registered. Please use a different phone number.")

#         if UserAuth.objects.filter(username=username).exists():
#             return error_response("Username is already taken. Please choose a different username.")

#         otp = random.randint(100000,999999)

#         otp_expire_at = datetime.now()+timedelta(minutes=30)

#         user_auth = Tbl_User_Auth.objects.create_user(
#             email=email,
#             phone_number=phone_number,
#             username=username,
#             password=password,
#             otp=otp,
#             otp_expire_at=otp_expire_at,
#             is_active=False
#         )

#         profile = ProfileTable.objects.create(
#             user_auth=user_auth,
#             full_name=full_name,
#             date_of_birth=date_of_birth
#         )

#         email_subject = 'OTP Verification'
#         email_message = f'Your OTP for email verification is: {otp}'
#         send_mail(email_subject, email_message, settings.EMAIL_HOST_USER, [email])

#         return created_response('Please check your email for OTP verification')

# class OTPVerificationView(APIView):
#     permission_classes = [AllowAny]

#     def post(self, request):
#         data = request.data
#         email = data.get('email')
#         otp_entered = data.get("otp")

#         if not all([email, otp_entered]):
#             return error_response("Email and OTP are required!")

#         try:
#             user = Tbl_User_Auth.objects.get(email=email)
#         except Tbl_User_Auth.DoesNotExist:
#             return error_response("User not found with the provided email")

#         current_datetime = datetime.now(timezone.utc)
#         if user.is_otp_expired or user.otp_expire_at < current_datetime:
#             return error_response("OTP has expired. Please request a new one.")

#         if user.otp == int(otp_entered):
#             user.is_email_verified = True
#             user.is_active = True
#             user.is_otp_expired = True
#             user.save()
#             serializer = UserAuthSerializer(user)
#             response_data = {
#                 'token': get_tokens_for_user(user),
#                 "user": serializer.data
#             }
#             return success_response("OTP verified successfully. Your account is now activated.", response_data)
#         return error_response("Invalid OTP. Please try again.")

class SigninView(APIView):
    def post(self, request):
        data =request.data
        countryCode= data.get('countryCode') 
        countryId=data.get('countryId')	 
        phone_number= data.get('phone_number')
        user = Tbl_User_Auth.objects.get(phone_number=phone_number)
        if user is not None:
            if user.is_active and user.isVerified:
                refresh = RefreshToken.for_user(user)
                refresh_token = str(refresh)
                access_token = str(refresh.access_token)
                response_date = {
                    'user_id' : user.id,
                    'refresh': refresh_token,
                    'access': access_token,
                }
                return Response(self, data=response_date, msg='success')
            else:
                return Response(self,  msg='User Is Not Active or Verified')
        else:
            return Response(self,  msg='Invalid Credentials')